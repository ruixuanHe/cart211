A Pen created at CodePen.io. You can find this one at https://codepen.io/-J0hn-/pen/XRqzqG.

 Inspiration: https://dribbble.com/shots/1560982-Rosa-Restaurant-Website/attachments/239212