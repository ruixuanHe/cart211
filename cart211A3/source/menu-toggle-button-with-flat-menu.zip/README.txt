A Pen created at CodePen.io. You can find this one at https://codepen.io/ruixuan-he/pen/gQjepB.

 Menu toggle button with flat menu. Uses CSS transitions and Vanilla JS.